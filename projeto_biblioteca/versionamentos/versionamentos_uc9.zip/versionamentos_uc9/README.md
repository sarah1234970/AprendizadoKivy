# Library System (Sistema de Biblioteca Educacional)

## Description
This is a simple educational library system developed in Python using the Kivy framework for the graphical interface and SQLite for data storage. The system allows login, user registration, book borrowing (basic CRUD), and user profile viewing.

## Current Version
**v1.4.0** - Evolutionary

## Features
- Login and user registration screen
- List of available books
- Book borrowing and returning functions (CRUD)
- User profile and loan viewing
- Optional phone field in registration
- Book search functionality
- Password recovery feature

## Database Structure
The system uses three main tables:

1. **usuarios**: Stores user information
   - id (primary key)
   - nome (name)
   - email (unique)
   - senha (password)
   - telefone (phone - optional)

2. **livros**: Stores book information
   - id (primary key)
   - titulo (title)
   - autor (author)
   - status (available or borrowed)

3. **emprestimos**: Stores loan records
   - id (primary key)
   - usuario_id (foreign key to usuarios)
   - livro_id (foreign key to livros)
   - data_emprestimo (loan date)
   - data_devolucao (return date)

## Requirements
- Python 3.7 or higher
- Kivy 2.1.0
- SQLite (included by default in Python)

## Installation
1. Clone or download the repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
   or
   ```
   pip install kivy[base]
   ```

## Execution
To run the system, execute the main file:
```
python main.py
```

## Project Structure
- `main.py`: Main application file
- `database.py`: SQLite database management module
- `screens.py`: Module containing application screens
- `library.db`: SQLite database file (generated automatically)

## Development
This project was created for educational purposes, demonstrating:
- Use of MVC pattern (Model-View-Controller)
- Database manipulation with SQLite
- Graphical interface with Kivy
- Screen management with ScreenManager

## Version History

### v1.4.0 (Evolutionary)
- Added book search functionality
- Implemented password recovery feature
- Improved database query optimization
- Enhanced visual appearance

### v1.3.0 (Perfective)
- Optimized database queries
- Significant improvements to the system appearance
- Improved error handling in the authentication process
- Enhanced data validation in registration

### v1.2.0 (Adaptive)
- Added 'telefone' field to users table
- Minor visual improvements to login screen
- Improved error handling in authentication process
- Enhanced data validation in registration

### v1.1.0 (Corrective)
- Fixed unrecognized login error
- Fixed user registration problem
- Improved error handling in authentication process
- Enhanced data validation in registration

### v1.0.0 (Initial Version)
- Basic implementation of library system
- Login and user registration screen
- List of available books screen
- Simple borrowing and returning function (CRUD)
- SQLite database with usuarios, livros, and emprestimos tables

## License
This project is intended for educational purposes only.